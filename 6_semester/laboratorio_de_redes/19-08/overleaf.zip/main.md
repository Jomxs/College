# Introdução

O modo *Simulation* do Cisco Packet Tracer permite acompanhar, de forma
visual e controlada, o tráfego de pacotes dentro de uma rede simulada.
Diferentemente do modo *Realtime*, no qual a comunicação ocorre de
maneira contínua, o modo de simulação possibilita pausar, avançar evento
a evento e inspecionar o conteúdo de cada pacote (PDU -- *Protocol Data
Unit*) enquanto ele percorre a rede.

Nesta atividade foi construída uma rede simples para explorar os
principais recursos desse modo: o envio de PDUs simples, a análise do
conteúdo dos pacotes nas diferentes camadas do modelo OSI, o envio de
PDUs complexas (incluindo tráfego periódico) e, por fim, o uso do modo
de simulação como ferramenta de diagnóstico em um cenário de rede
propositalmente mal configurado.

# Objetivos

- Construir uma rede local simples com três computadores e um switch.

- Utilizar o modo *Simulation* do Packet Tracer, incluindo a
  configuração de filtros de protocolo visíveis.

- Enviar PDUs simples (ICMP) entre dois computadores, de forma
  automática e manual.

- Analisar o conteúdo de um pacote nas abas *OSI Model* e *Outbound PDU
  Details*.

- Utilizar o recurso de PDU Complexa para enviar pacotes configuráveis,
  incluindo tráfego periódico.

- Diagnosticar, com o auxílio do modo de simulação, uma rede com
  problemas de comunicação previamente configurada.

# Metodologia

A atividade foi realizada utilizando o software Cisco Packet Tracer.
Inicialmente foi montada uma rede local composta por um switch Cisco
2960 e três computadores (PC1, PC2 e PC3), interligados por cabos
*Copper Straight-Through*. Foram configurados os endereços IP estáticos
192.168.0.1, 192.168.0.2 e 192.168.0.3 para os três computadores,
respectivamente.

Em seguida, o modo *Simulation* foi ativado no painel do lado direito da
interface. Na aba de simulação, o botão *Edit Filters* foi utilizado
para acessar a lista de protocolos monitorados; a opção *Show All/None*
foi usada para desmarcar todos os protocolos, e apenas o protocolo ICMP
foi selecionado, de modo a manter a lista de eventos limpa e focada no
tráfego relevante para a atividade.

Com o filtro configurado, um PDU simples (ícone de carta fechada) foi
enviado do PC1 para o PC2, e a simulação foi executada primeiro em modo
automático (botão de *play*) e, após um *Reset Simulation*, repetida em
modo manual, avançando evento a evento.

Durante a simulação, um dos pacotes em trânsito foi selecionado para
inspeção, sendo analisadas as informações disponíveis na aba *OSI Model*
e na aba *Outbound PDU Details*, com atenção especial aos campos de
endereçamento IP e MAC do cabeçalho.

Na etapa seguinte, a simulação foi limpa (*Delete* na lista de eventos)
e um PDU Complexo (ícone de carta aberta) foi enviado do PC1 ao PC2,
configurando um ping com *Sequence Number* 1 e *Size* 0. O procedimento
foi repetido configurando um envio periódico de dois pings por segundo.

Por fim, foi carregado o cenário `rede_com_problemas.pkt`, contendo uma
rede com falhas de configuração. A comunicação entre todos os pares de
PCs foi testada, e o modo de simulação foi utilizado para rastrear os
pacotes e identificar a origem das falhas de comunicação observadas.

# Resultados

## Construção da Rede Simples

Foi montada uma rede composta por um switch Cisco 2960 e três
computadores, conectados por cabos *Copper Straight-Through*. Os
endereços IP 192.168.0.1, 192.168.0.2 e 192.168.0.3 foram atribuídos a
PC1, PC2 e PC3, respectivamente, todos na mesma sub-rede.

<figure id="fig:topologia" data-latex-placement="H">

<figcaption>Topologia da rede simples montada no Cisco Packet
Tracer</figcaption>
</figure>

## Simulação Simples com PDU ICMP

Com o modo *Simulation* ativado e o filtro configurado para exibir
apenas eventos ICMP, um PDU simples foi enviado do PC1 para o PC2. Na
execução automática, o pacote foi observado percorrendo o caminho PC1
$\rightarrow$ Switch $\rightarrow$ PC2, com o retorno da resposta ICMP
pelo mesmo caminho, sendo o evento classificado como *Successful* na
lista de eventos.

Ao repetir o procedimento em modo manual, cada clique no botão de avanço
revelou um único evento por vez (por exemplo, a saída do quadro do PC1,
sua chegada ao switch e o subsequente encaminhamento ao PC2), permitindo
observar isoladamente cada salto do pacote pela rede.

## Visualização da PDU

Durante a simulação, um dos pacotes ICMP em trânsito foi selecionado
para inspeção do seu conteúdo.

Na aba *OSI Model*, observou-se que apenas as camadas 1 a 3 apresentavam
informações preenchidas. Isso ocorre porque o ICMP não é um protocolo de
camada de transporte: ele é encapsulado diretamente sobre o IP (camada
de rede), sendo utilizado para mensagens de controle e diagnóstico, como
as requisições e respostas de eco do comando ping. Como não há TCP ou
UDP envolvido no ping, não existem portas de origem e destino nem
qualquer dado de camadas superiores (4 a 7) a ser exibido.

Já na aba *Outbound PDU Details*, o cabeçalho IP exibe os campos
`SRC IP` e `DST IP`, mostrando que, na camada de rede, o pacote é
endereçado logicamente ao IP da máquina de destino (por exemplo,
`DST IP: 192.168.0.2`). No cabeçalho ICMP encapsulado, aparecem ainda os
campos `TYPE`, `CODE` e `CHECKSUM`, característicos das mensagens de
eco.

<figure id="fig:outbound-pdu" data-latex-placement="H">

<figcaption>Aba Outbound PDU Details com o cabeçalho IP e ICMP do
pacote</figcaption>
</figure>

Observando também o quadro Ethernet correspondente (camada 2),
verificou-se que, como PC1 e PC2 pertencem à mesma sub-rede e ao mesmo
domínio de broadcast, o quadro é endereçado diretamente ao endereço MAC
do PC2, previamente resolvido via ARP. Ou seja: o endereçamento de
camada 3 (IP) aponta sempre para o destino final, enquanto o
endereçamento de camada 2 (MAC) aponta para o próximo salto físico --
que só coincide com o MAC do destino final quando ambos estão na mesma
rede local.

## PDU Complexa e Pings Periódicos

Utilizando o recurso de PDU Complexa, foi configurado um ping do PC1
para o PC2 com *Sequence Number* 1 e *Size* 0, reproduzindo um
comportamento equivalente ao PDU simples, porém com maior controle sobre
os parâmetros do pacote enviado.

Em seguida, o mesmo recurso foi utilizado para configurar um envio
periódico de pings, com uma taxa de dois pacotes por segundo entre PC1 e
PC2. Durante a execução, a lista de eventos passou a exibir múltiplos
pacotes ICMP consecutivos, evidenciando o caráter contínuo e repetitivo
desse tipo de tráfego, em contraste com o envio único proporcionado pelo
PDU simples.

<figure id="fig:pdu-complexa" data-latex-placement="H">

<figcaption>Configuração de PDU Complexa com envio periódico de pings (2
por segundo)</figcaption>
</figure>

Esse recurso demonstrou ser mais genérico que o PDU simples, permitindo
configurar diversos parâmetros do pacote (tipo de PDU, tamanho, número
de sequência, periodicidade), sendo útil para simular cenários de
tráfego mais próximos de situações reais de rede.

## Diagnóstico da Rede com Problemas de Configuração

O cenário `rede_com_problemas.pkt` é composto por um switch Cisco 2960,
um roteador Cisco 2901 e quatro computadores, divididos em duas
sub-redes: PC0 e PC2 pertencem à *Rede 1* (192.168.0.0/24), enquanto PC1
e PC3 pertencem à *Rede 2* (192.168.1.0/24), conforme ilustrado na
[4](#fig:rede-problemas-topo){reference-type="ref+Label"
reference="fig:rede-problemas-topo"}. As duas sub-redes são interligadas
exclusivamente pelo Router0, de modo que qualquer comunicação entre um
host da Rede 1 e um host da Rede 2 depende necessariamente do roteamento
realizado por esse dispositivo -- o switch opera apenas na camada 2 e
não é capaz de encaminhar tráfego entre redes IP distintas.

<figure id="fig:rede-problemas-topo" data-latex-placement="H">

<figcaption>Topologia do cenário <code>rede_com_problemas.pkt</code>,
com falha de comunicação sinalizada (X vermelho) sobre o
PC1</figcaption>
</figure>

Ao testar a comunicação entre todos os pares de PCs, o ping entre hosts
da mesma sub-rede (PC0 $\leftrightarrow$ PC2, na Rede 1) funcionou
normalmente. Já os testes envolvendo o PC1 (Rede 2) apresentaram falha
logo nos primeiros pacotes, com o modo de simulação indicando um X
vermelho sobre o PC1 no momento em que o pacote deveria ser processado.

Para identificar a causa, foram inspecionadas as configurações de IP dos
hosts envolvidos e das interfaces do roteador, resumidas na
[1](#tab:diagnostico){reference-type="ref+Label"
reference="tab:diagnostico"}.

::: {#tab:diagnostico}
  Dispositivo         Rede     Endereço IP    Máscara         Gateway padrão
  ------------------- -------- -------------- --------------- ----------------
  PC2                 Rede 1   192.168.0.11   255.255.255.0   192.168.0.1
  Router0 -- Gig0/0   Rede 1   192.168.0.1    255.255.255.0   --
  PC1                 Rede 2   192.168.1.10   255.255.255.0   192.168.1.1
  Router0 -- Gig0/1   Rede 2   192.168.1.2    255.255.255.0   --

  : Configurações de IP levantadas no diagnóstico
:::

Os valores de PC2 e da interface Gig0/0 (Rede 1) foram levantados apenas
para efeito de comparação e não requerem figura própria, por já estarem
resumidos na [1](#tab:diagnostico){reference-type="ref+Label"
reference="tab:diagnostico"}. As duas configurações que efetivamente
evidenciam o problema -- o gateway do PC1 e a interface Gig0/1 do
roteador -- são mostradas a seguir.

<figure id="fig:pc1-ip" data-latex-placement="H">

<figcaption>Configuração IP do PC1 (Rede 2), com o <em>Default
Gateway</em> <code>192.168.1.1</code></figcaption>
</figure>

<figure id="fig:gig01" data-latex-placement="H">

<figcaption>Configuração da interface GigabitEthernet0/1 do Router0, com
o IP real <code>192.168.1.2</code></figcaption>
</figure>

Na Rede 1, a configuração está consistente: o gateway padrão do PC2
(192.168.0.1) corresponde exatamente ao IP configurado na interface
Gig0/0 do Router0, que é a interface conectada a essa sub-rede.

Na Rede 2, entretanto, foi identificada uma inconsistência: o gateway
padrão configurado no PC1 é `192.168.1.1`, mas a interface real do
roteador voltada para essa sub-rede (Gig0/1) está configurada com o IP
`192.168.1.2`. Embora ambos os endereços pertençam à mesma sub-rede
(192.168.1.0/24) -- descartando um erro de máscara --, o endereço
192.168.1.1 não corresponde a nenhum dispositivo existente na rede. Como
consequência, o PC1 não consegue resolver via ARP o endereço MAC de seu
suposto gateway, e os pacotes destinados a outras sub-redes nunca chegam
a ser encaminhados pelo roteador, causando a falha observada (*Request
Timed Out*) logo no início da simulação.

A correção do problema pode ser feita de duas formas equivalentes: (i)
alterar o *Default Gateway* do PC1 para `192.168.1.2`, de modo a apontar
para o endereço real da interface do roteador; ou (ii) alterar o IPv4
Address da interface Gig0/1 do Router0 para `192.168.1.1`, de modo a
corresponder ao gateway já configurado no host. Por se tratar de um erro
de configuração do host, optou-se pela primeira alternativa, corrigindo
o *Default Gateway* do PC1 para `192.168.1.2`. Após a correção, a
simulação foi reiniciada e o ping entre PC1 e os demais computadores da
Rede 1 passou a ser concluído com sucesso.

# Discussão

A atividade permitiu aprofundar a compreensão sobre o funcionamento
interno da comunicação em uma rede de computadores por meio do modo
*Simulation* do Cisco Packet Tracer.

O envio de PDUs simples, tanto em modo automático quanto manual,
evidenciou que a comunicação entre dois hosts na mesma rede local passa
por etapas bem definidas -- saída do quadro do host de origem,
encaminhamento pelo switch e chegada ao host de destino -- que podem ser
observadas isoladamente quando a simulação é avançada manualmente.

A inspeção do conteúdo dos pacotes nas abas *OSI Model* e *Outbound PDU
Details* reforçou a diferença entre o endereçamento lógico (IP, camada
3) e o endereçamento físico (MAC, camada 2), além de esclarecer por que
protocolos de controle como o ICMP não apresentam informações de camadas
superiores à de rede.

O uso de PDUs complexas, em especial o envio periódico de pings,
mostrou-se um recurso mais flexível que o PDU simples, aproximando-se de
cenários de tráfego contínuo, o que é útil tanto para testes de
conectividade prolongados quanto para observar o comportamento da rede
sob carga repetida.

Por fim, o diagnóstico da rede mal configurada demonstrou, na prática, a
utilidade do modo de simulação como ferramenta de *troubleshooting*: ao
rastrear o caminho real de cada pacote e comparar os endereços IP e MAC
envolvidos em cada salto, foi possível identificar exatamente em que
ponto e por qual motivo a comunicação estava falhando, algo que seria
mais difícil de perceber apenas observando o resultado final do comando
ping.

# Conclusão

A atividade proporcionou uma exploração prática do modo de simulação do
Cisco Packet Tracer, cobrindo desde o envio de PDUs simples até o uso
desse recurso como ferramenta de diagnóstico de redes.

Foi possível compreender a diferença entre a execução automática e
manual de uma simulação, analisar em detalhe o conteúdo dos pacotes
trafegados nas camadas OSI e entender a distinção entre o endereçamento
IP e o endereçamento MAC ao longo do caminho percorrido por um pacote.

O uso de PDUs complexas, incluindo o tráfego periódico, ampliou a
compreensão sobre a flexibilidade das ferramentas de teste disponíveis
no software. Por fim, o exercício de diagnóstico em uma rede mal
configurada consolidou o entendimento de que o modo de simulação, ao
permitir o rastreamento detalhado de cada pacote, é uma ferramenta
poderosa para identificar e corrigir falhas de comunicação em redes de
computadores.

# Perguntas de Fixação

**Por que não há nenhuma informação de camada quatro em diante ao
inspecionar um pacote ICMP na aba OSI Model?**

Porque o ICMP não é um protocolo de camada de transporte: ele é
encapsulado diretamente sobre o IP (camada 3) e utilizado para mensagens
de controle e diagnóstico da rede, como as requisições e respostas de
eco do ping. Como não há TCP ou UDP envolvido, não existem portas de
origem e destino nem qualquer dado de camadas 4 a 7 a ser exibido.

**De acordo com o cabeçalho, o pacote está endereçado ao IP ou ao MAC da
máquina alvo?**

O cabeçalho IP mostra que, na camada 3, o pacote é endereçado
logicamente ao IP de destino da máquina alvo. Já o quadro Ethernet que
carrega esse pacote é endereçado, na camada 2, ao MAC do próximo salto
físico: quando origem e destino estão na mesma rede local, esse MAC
coincide com o do destino final (obtido via ARP); quando estão em redes
diferentes, o MAC de destino do quadro é o do roteador (gateway padrão),
e não o do host final.

**Quais PCs estão com problema de comunicação na rede
`rede_com_problemas.pkt` e por que alguns pacotes precisam passar pelo
roteador?**

O PC1, pertencente à Rede 2 (192.168.1.0/24), apresentou falha de
comunicação com os hosts da Rede 1 (PC0 e PC2, em 192.168.0.0/24). A
causa foi um *Default Gateway* incorreto configurado no PC1
(`192.168.1.1`), que não correspondia ao IP real da interface do Router0
voltada para essa sub-rede (Gig0/1, com IP `192.168.1.2`). Pacotes
destinados a outras sub-redes precisam necessariamente passar pelo
roteador porque o switch opera apenas na camada 2 e só encaminha quadros
dentro do mesmo domínio de broadcast; a travessia entre redes IP
distintas exige um dispositivo de camada 3, que decide o próximo salto
com base em sua tabela de roteamento -- e é justamente por o PC1 não
conseguir alcançar esse dispositivo (seu gateway) que a comunicação
falhava.

**Como o modo de simulação e os PDUs podem ser utilizados para
diagnosticar problemas em uma rede?**

O modo de simulação permite acompanhar passo a passo o caminho
percorrido por cada pacote e inspecionar seu cabeçalho a cada salto.
Rastreando os campos `SRC IP` e `DST IP`, bem como os endereços MAC de
origem e destino em cada trecho da rede, é possível identificar
exatamente em qual dispositivo (PC, switch ou roteador) e em qual camada
(2 ou 3) a comunicação está sendo interrompida, revelando problemas como
endereçamento incorreto, máscara de sub-rede incompatível ou ausência de
rota/gateway.
